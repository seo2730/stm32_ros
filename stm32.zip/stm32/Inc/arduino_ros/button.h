#ifndef _ROS_arduino_ros_button_h
#define _ROS_arduino_ros_button_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace arduino_ros
{

  class button : public ros::Msg
  {
    public:
      typedef bool _button0_type;
      _button0_type button0;
      typedef bool _button1_type;
      _button1_type button1;
      typedef bool _button2_type;
      _button2_type button2;
      typedef bool _button3_type;
      _button3_type button3;
      typedef bool _button4_type;
      _button4_type button4;

    button():
      button0(0),
      button1(0),
      button2(0),
      button3(0),
      button4(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_button0;
      u_button0.real = this->button0;
      *(outbuffer + offset + 0) = (u_button0.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->button0);
      union {
        bool real;
        uint8_t base;
      } u_button1;
      u_button1.real = this->button1;
      *(outbuffer + offset + 0) = (u_button1.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->button1);
      union {
        bool real;
        uint8_t base;
      } u_button2;
      u_button2.real = this->button2;
      *(outbuffer + offset + 0) = (u_button2.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->button2);
      union {
        bool real;
        uint8_t base;
      } u_button3;
      u_button3.real = this->button3;
      *(outbuffer + offset + 0) = (u_button3.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->button3);
      union {
        bool real;
        uint8_t base;
      } u_button4;
      u_button4.real = this->button4;
      *(outbuffer + offset + 0) = (u_button4.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->button4);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_button0;
      u_button0.base = 0;
      u_button0.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->button0 = u_button0.real;
      offset += sizeof(this->button0);
      union {
        bool real;
        uint8_t base;
      } u_button1;
      u_button1.base = 0;
      u_button1.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->button1 = u_button1.real;
      offset += sizeof(this->button1);
      union {
        bool real;
        uint8_t base;
      } u_button2;
      u_button2.base = 0;
      u_button2.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->button2 = u_button2.real;
      offset += sizeof(this->button2);
      union {
        bool real;
        uint8_t base;
      } u_button3;
      u_button3.base = 0;
      u_button3.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->button3 = u_button3.real;
      offset += sizeof(this->button3);
      union {
        bool real;
        uint8_t base;
      } u_button4;
      u_button4.base = 0;
      u_button4.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->button4 = u_button4.real;
      offset += sizeof(this->button4);
     return offset;
    }

    const char * getType(){ return "arduino_ros/button"; };
    const char * getMD5(){ return "56f926a37f99a51cc0bcec3c74fa2890"; };

  };

}
#endif