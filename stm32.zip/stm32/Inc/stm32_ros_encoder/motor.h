#ifndef _ROS_stm32_ros_encoder_motor_h
#define _ROS_stm32_ros_encoder_motor_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace stm32_ros_encoder
{

  class motor : public ros::Msg
  {
    public:
      typedef float _current_type;
      _current_type current;
      typedef float _velocity_type;
      _velocity_type velocity;
      typedef float _degree_type;
      _degree_type degree;

    motor():
      current(0),
      velocity(0),
      degree(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_current;
      u_current.real = this->current;
      *(outbuffer + offset + 0) = (u_current.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_current.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_current.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_current.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->current);
      union {
        float real;
        uint32_t base;
      } u_velocity;
      u_velocity.real = this->velocity;
      *(outbuffer + offset + 0) = (u_velocity.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_velocity.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_velocity.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_velocity.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->velocity);
      union {
        float real;
        uint32_t base;
      } u_degree;
      u_degree.real = this->degree;
      *(outbuffer + offset + 0) = (u_degree.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_degree.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_degree.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_degree.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->degree);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_current;
      u_current.base = 0;
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_current.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->current = u_current.real;
      offset += sizeof(this->current);
      union {
        float real;
        uint32_t base;
      } u_velocity;
      u_velocity.base = 0;
      u_velocity.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_velocity.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_velocity.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_velocity.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->velocity = u_velocity.real;
      offset += sizeof(this->velocity);
      union {
        float real;
        uint32_t base;
      } u_degree;
      u_degree.base = 0;
      u_degree.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_degree.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_degree.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_degree.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->degree = u_degree.real;
      offset += sizeof(this->degree);
     return offset;
    }

    const char * getType(){ return "stm32_ros_encoder/motor"; };
    const char * getMD5(){ return "cce2f0e5e96cc7f593a28c4a42d40984"; };

  };

}
#endif
